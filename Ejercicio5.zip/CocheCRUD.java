package com.example.tema5.ejercicio5;

public interface CocheCRUD {

    void save();

    String findAll();

    void delete();
}

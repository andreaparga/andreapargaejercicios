package com.example.tema5.ejercicio5;

public class CocheCRUDImpl implements CocheCRUD {
    @Override
    public void save() {
        System.out.println("SAVE");
    }

    @Override
    public String findAll() {
        return "findAll";
    }

    @Override
    public void delete() {
        System.out.println("DELETE");
    }
}

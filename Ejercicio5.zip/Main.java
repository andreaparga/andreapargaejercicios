package com.example.tema5.ejercicio5;

public class Main {

    static CocheCRUD cocheCRUD = new CocheCRUDImpl();
    public static void main(String[] args) {

        cocheCRUD.save();

        System.out.println(cocheCRUD.findAll());

        cocheCRUD.delete();
    }
}
